package common;

public class delete_DTO {
	private String name;
    private int price;

    // 생성자
    public delete_DTO(String name, int price) {
        this.name = name;
        this.price = price;
    }

    // Getter 및 Setter
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
