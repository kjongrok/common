// MainClass.java
package common;

import java.util.Scanner;

public class MainClass {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        TestClass04 testClass04 = new TestClass04();
       
        int num;
        while(true) {
            System.out.println("1.금액 투입");
            System.out.println("2.메뉴 선택");
            System.out.println("3.메뉴 수정");
            System.out.println("4.메뉴 삭제");
            System.out.println("5.잔돈 반환");
            System.out.println("6.종료");
            System.out.print("선택: ");
            num = input.nextInt();
            switch (num) {
                case 1:
                    // 금액 투입 
                    break;
                case 2:
                    // 메뉴 선택 
                    break;
                case 3:
                    // 메뉴 수정 
                    break;
                case 4:
                    // 메뉴 삭제 기능 호출
                	testClass04.deleteMenu();
                    break;
                case 5:
                    // 잔돈 반환 관련 로직
                    break;
                case 6:
                	// 프로그램 종료
                    System.out.println("프로그램을 종료합니다.");
                    input.close(); // Scanner 닫기
                    System.exit(0); // 프로그램 종료
                    break;
                default:
                    System.out.println("잘못된 선택입니다. 다시 시도하세요.");
                    break;
            }
        }
    }
}
