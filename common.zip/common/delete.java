package common;

import java.util.HashMap;
import java.util.Scanner;

public class delete {
    private HashMap<String, delete_DTO> menu = new HashMap<>();

    // 생성자에서 기본 메뉴 설정
    public delete() {
        menu.put("콜라", new delete_DTO("콜라", 2000));
        menu.put("사이다", new delete_DTO("사이다", 2000));
        menu.put("커피", new delete_DTO("커피", 1500));
    }

    // 메뉴 삭제 메서드
    public void deleteMenu() {
        Scanner input = new Scanner(System.in);
        System.out.println("삭제할 메뉴 입력: ");
        String name = input.next();

        // 메뉴 존재 여부 확인
        if (menu.containsKey(name)) {
            menu.remove(name);
            System.out.println(name + " 메뉴가 삭제되었습니다.");
        } else {
            System.out.println("존재하지 않는 메뉴입니다.");
        }
    }
}