package common;

import java.util.HashMap;

public class SelectDTO {
	private HashMap<String, Integer> menu = new HashMap<>();

	public HashMap<String, Integer> getMenu() {
		return menu;
	}

	public void setMenu(HashMap<String, Integer> menu) {
		this.menu = menu;
	}
	
	
	
}

