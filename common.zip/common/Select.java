package common;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class Select{
	Scanner sc = new Scanner(System.in); 
	
	public void display() {
		System.out.println("=== 메뉴 선택 ===");
		
	}
	
	public void setDefault(HashMap<String, Integer> menu) {	// 메뉴의 기본값을 세팅하는 메서드
		menu.put("커피", 1500);
		menu.put("콜라", 2000);
		menu.put("사이다", 2000);
		System.out.println("초기 세팅이 완료되었습니다.\n");
	}
	
	private void showMenu(HashMap<String, Integer> menu) {	// 현재 메뉴를 보여주는 메서드 
		Iterator<String> it = menu.keySet().iterator();		// 전달받은 해시맵의 키들을 set으로 모음(menu.keyset) ->
		int idx = 1;										// -> set의 요소들을 확인하기 위해 iterator <it>를 만듦
		while(it.hasNext()) {								// <it>의 요소가 남아있으면 반복문 진행
			String bev = it.next();							// <it>의 요소를 bev에 저장, menu.get(bev) : bev라는 키를 가지는 요소의 값 ex) key = "커피"인 경우 get("커피") = 1500 
			System.out.print(idx +"." + bev + "(" + menu.get(bev) + ") ");
			idx++;											// 원하는 모양으로 출력
			}
		System.out.println();
	}
	
	public int runSelect(HashMap<String, Integer> menu, int balance) {	// 선택과정을 진행하는 메서드, 메뉴판과 잔액을 전달받아 메뉴를 선택하고 잔액을 반환함(메인클래스에서 받아 쓰면 됨)
									// 잔액은 메인클래스에서 받아와야함, 여기서는 임시로 만원 넣고 시작
		while(true) {										
			
			showMenu(menu);									// 위에서 만든 showMenu 메서드 호출
			System.out.println("메뉴를 한글로 입력하세요 >>>");
			String sel = sc.next();							// 메뉴를 문자열로 입력받음
			if(menu.containsKey(sel)) {						// 입력받은 문자열이 메뉴에 있는 경우
				if(balance >= menu.get(sel)) {				// 잔액이 충분히 있다면
					balance -= menu.get(sel);				// 음료 가격만큼 잔액 차감
					System.out.println("맛있게 드세요");
					System.out.println("현재 잔액 : " + balance + "원"); // 잔액 출력
					return balance;				//메서드를 종료하면서 잔액 반환, 반환한 잔액은 메인클래스에서 받아서 활용 
				}								//ex) balance = rumSelect(menu, inputmoney);
				else {
					System.out.println("잔액이 부족합니다.");	
					return balance;
				}
				
			}
			else {											// 입력받은 문자열이 메뉴에 없는 경우
				System.out.println("존재하지 않는 메뉴입니다\n");
			}
		}
		
		
		
	}
}