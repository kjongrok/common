package common;

import java.util.HashMap;
import java.util.Scanner;

public class ChangeDto {
	private HashMap<String, Integer> menu = new HashMap<>();
	
	public HashMap<String, Integer> getmenu() {
		return menu;
	}
	
	public void setmenu(HashMap<String, Integer> menu) {
		this.menu = menu;
	}
	

}
