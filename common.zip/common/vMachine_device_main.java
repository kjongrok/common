package common;

public class vMachine_device_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		vMachine_device de = new vMachine_device();
		de.device();
		
		

	}

}
