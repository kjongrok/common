package common;

import java.util.Scanner;

public class vMachine_device {
	
	public void device () {
	Scanner input = new Scanner(System.in);
	
	vMachine_inputmoney inMoney = new vMachine_inputmoney();
	vMachine_change change = new vMachine_change();
	vMachine_choice choice = new vMachine_choice();
		
	
	inMoney.inputMoney();
	change.change();
	choice.main(null);
	
	}	
}

