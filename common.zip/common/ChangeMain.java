package common;

import java.util.HashMap;
import java.util.Scanner;

	public class ChangeMain{
	public void Change() {
		Scanner sc = new Scanner(System.in);
		ChangeDto ch = new ChangeDto();
		HashMap<String, Integer> menu = new HashMap<String, Integer>();
		
		menu.put("커피", 1500);
		menu.put("콜라", 2000);
		menu.put("사이다", 1000);
		ch.setmenu(menu);
		
		ch.getmenu();
		System.out.println("변경하실 메뉴의 이름을 입력하세요 : ");
		String change = sc.next();
		if (menu.containsKey(change)) { // 입력한 메뉴값과 map안에 있는 배열 비교
			menu.remove(change); // 입력한 메뉴값과 map 배열 일치 시 해당 값 삭제
			System.out.println("변경하실 메뉴의 이름을 입력하세요 : ");
			change = sc.next();
			System.out.println("변경하실 메뉴의 가격을 입력하세요 : ");
			int price = sc.nextInt();
			menu.put(change, price); // 변경할 값 map 배열에 저장
		}else {
			System.out.println("존재하지 않는 메뉴입니다.");
		}

	
}
}



















