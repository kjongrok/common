package common;

import java.util.Scanner;

public class vMachine_inputmoney { //경천
	
	
	
		public int inputMoney () {
		vMachine_inputmoney_DTO mn = new vMachine_inputmoney_DTO();
		Scanner input = new Scanner(System.in);
		int inputMoney = 0, num;
		
		System.out.println("=== 자판기 ===");
		while(true) {
			System.out.println("1.금액 투입");
	        System.out.println("2.메뉴 선택");
	        System.out.println("3.메뉴 수정");
	        System.out.println("4.메뉴 삭제");
	        System.out.println("5.잔돈 반환");
	        System.out.println("6.종료");
	        System.out.print("선택: ");
	        num = input.nextInt();
	        
			switch (num) {
			case 1 :
				System.out.print("투입 금액 : ");
				inputMoney = input.nextInt();
				System.out.println(inputMoney + "원 투입 되었습니다!");
				break;				
			case 2 : break;
			case 3 : break;
			case 4 : break;
			case 5 : break;
			case 6 : break;
			}
			
			
		}						
		
	} 
		
}
	



