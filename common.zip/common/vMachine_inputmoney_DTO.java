package common;

import java.util.Scanner;

public class vMachine_inputmoney_DTO { // 경천
	
	public void  getinputMoney() {
		return;
	}
	public void setinputMoney() {
		return;
	}
}